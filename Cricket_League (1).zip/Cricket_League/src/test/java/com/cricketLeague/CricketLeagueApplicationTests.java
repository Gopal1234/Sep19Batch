package com.cricketLeague;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CricketLeagueApplicationTests {

	@Test
	void contextLoads() {
	}

}
