package com.cricketLeague.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cricketLeague.model.Organiser;
import com.cricketLeague.service.IOrganiserService;

@RestController
@CrossOrigin("*")
public class OrganiserContoller {
	
	@Autowired
	private IOrganiserService service;
	
	@PostMapping(path = "/add/organiser")
	public Organiser addOrganiser(@RequestBody Organiser organiser){  
		return service.insertOrganiser(organiser);
	}
	
	@GetMapping(path = "/allOrganisers")
	public List<Organiser> getAllOrganisers(){
		return service.getAllOrganisers();
	}
	
	@GetMapping(path = "/getOrganiser/{id}")
	public Organiser getOrganiser(@PathVariable int id){
		return service.getOrganiser(id);
	}
	
	@PutMapping(path = "/updateOrganiser")
	public int updateOrganiser(@RequestBody Organiser organiser) {
		return service.updateOrganiser(organiser);
	}
	
	@DeleteMapping(path = "/deleteOrganiser/{id}")
	public int deleteOrganiser(@PathVariable int id) {
		return service.deleteOrgainiser(id);
	}
	
	@GetMapping(path = "/organiser/login/{email}/{password}")
	public Organiser loginOrganiser(@PathVariable String email,@PathVariable String password) {
		return service.loginOrganiser(email, password);
	}
	
	@GetMapping(path = "/organiser/getId/{name}")
	public int loginOrganiser(@PathVariable String name){
		return service.fetchOrganiserId(name);
	}
}
