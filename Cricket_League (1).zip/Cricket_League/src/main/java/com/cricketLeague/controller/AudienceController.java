package com.cricketLeague.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cricketLeague.model.Audience;
import com.cricketLeague.model.Match;
import com.cricketLeague.service.IAudienceService;

@RestController
public class AudienceController {
	
	@Autowired
	private IAudienceService service;
	
	@GetMapping(path = "getAudienceById/{id}")
	public Audience getAudience(@PathVariable int id) {
		return service.getAudience(id);
	}
	
	@PostMapping(path = "/add/Audience")
	public Audience addproduct(@RequestBody Audience audience) {
		return service.insertAudience(audience);
	}
	
	//@GetMapping(path = "getMatchById/{Audienceid}")
	//public Match getMatch(@PathVariable int Audienceid) {
	//	return service.getMatch(Audienceid);
	//}
	
	
	
    
}
