package com.cricketLeague.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cricketLeague.model.Match;
import com.cricketLeague.service.IMatchService;

@RestController
public class MatchController {
	
	@Autowired
	private IMatchService service;
	
	@PostMapping(value = "/match/get")
	public Match getMatch(int matchId) {
		return service.getMatch(matchId);
	}
	
	@GetMapping(value = "/match/insert")
	public Match insertMatch(Match match) {
		return service.insertMatch(match);
	}

}
