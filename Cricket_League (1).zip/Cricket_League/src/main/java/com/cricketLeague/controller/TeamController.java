package com.cricketLeague.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cricketLeague.model.Team;
import com.cricketLeague.service.ITeamService;

@RestController
@CrossOrigin("*")
public class TeamController {

	@Autowired
	private ITeamService service;
	
	@PostMapping(path = "team/add")
	public Team insertTeam(@RequestBody Team team)
	{
	   
	   return service.insertTeam(team);
	}
   @GetMapping(path="team/viewAll")
   public List<Team> getAllTeams()
   {
	   return service.getAllTeams();
   }
   
   @GetMapping(path="/team/{teamId}")
   public Team getTeam(@PathVariable int teamId) {
	   return service.getTeam(teamId);
   }
   @PutMapping(path="/team/update")
   public int updateTeam(Team team) {
	   return service.updateTeam(team);
   }
   @DeleteMapping("/team/{teamId}")
   public int deleteTeam(@PathVariable int teamId) {
     return service.deleteTeam(teamId);
   }
}
