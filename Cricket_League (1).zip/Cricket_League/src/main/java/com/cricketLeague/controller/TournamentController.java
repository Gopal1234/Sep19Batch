package com.cricketLeague.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.cricketLeague.model.Tournament;
import com.cricketLeague.service.ITournamentService;

@RestController
@CrossOrigin("*")
public class TournamentController {
	
	@Autowired
	private ITournamentService service;
	
	@PostMapping(path="tournaments/add")
	public Tournament insertTournament(@RequestBody Tournament tournamentObj) {
		return service.insertTournament(tournamentObj);
	}
	 
	@GetMapping(path="tournaments/viewall")
	public List<Tournament> getAllTournaments() {
		return service.getAllTournaments();
	}
	
	@GetMapping(path="tournaments/get/{tournamentId}")
	public Tournament getTournament(@PathVariable int tournamentId) {
		return service.getTournament(tournamentId);
	}
	
	@DeleteMapping(path="tournaments/delete/{tournamentId}")
	public int deleteProduct(@PathVariable int tournamentId) {
		return service.deleteTournament(tournamentId);
	}
	
	@PutMapping(path="tournaments/update")
	public int updateTournament(@RequestBody Tournament tournament) {
		return service.updateTournament(tournament);
	}
	 
}
