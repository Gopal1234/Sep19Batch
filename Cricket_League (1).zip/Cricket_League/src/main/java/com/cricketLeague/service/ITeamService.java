package com.cricketLeague.service;

import java.util.List;

import com.cricketLeague.model.Player;
import com.cricketLeague.model.Team;


public interface ITeamService {

	public Team getTeam(int teamId);

	public List<Team> getAllTeams();

	public Team insertTeam(Team team);

	public int updateTeam(Team team);

	public int deleteTeam(int teamId);

	/*public List<Player> getAllPlayers();

	public Player getPlayer(int teamId, int playerId);

	public Team getTeam(Player player);*/

}
