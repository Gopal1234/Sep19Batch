package com.cricketLeague.service;

import java.util.List;

import com.cricketLeague.model.Audience;
import com.cricketLeague.model.Match;
import com.cricketLeague.model.Ticket;

public interface IAudienceService {

	public Audience getAudience(int audienceId);

	public Audience insertAudience(Audience audience);

	
	

}
