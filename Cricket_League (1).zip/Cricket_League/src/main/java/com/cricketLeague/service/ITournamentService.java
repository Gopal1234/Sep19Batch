package com.cricketLeague.service;

import java.util.List;

import com.cricketLeague.model.Match;
import com.cricketLeague.model.Tournament;


public interface ITournamentService {

	public Tournament getTournament(int tournamentId);

	public List<Tournament> getAllTournaments();

	public Tournament insertTournament(Tournament tournament);

	public int updateTournament(Tournament tournament);

	public int deleteTournament(int tournamentId);

	
}
