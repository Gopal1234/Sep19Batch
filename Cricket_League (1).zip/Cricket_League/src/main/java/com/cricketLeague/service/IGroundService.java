package com.cricketLeague.service;

import java.util.List;

import com.cricketLeague.model.Ground;
import com.cricketLeague.model.Match;


public interface IGroundService {

	public List<Match> getAllmatchesGround(int groungId);

	public Ground insertGround(Ground ground);

	public int updateGround(Ground ground);

	public int deleteGround(int groungId);


}
