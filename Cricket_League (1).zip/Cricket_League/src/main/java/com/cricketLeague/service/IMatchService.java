package com.cricketLeague.service;

import com.cricketLeague.model.Match;


public interface IMatchService {

	public Match getMatch(int matchId);

	public Match insertMatch(Match match);

//	public int updateMatch(Match match);

}
