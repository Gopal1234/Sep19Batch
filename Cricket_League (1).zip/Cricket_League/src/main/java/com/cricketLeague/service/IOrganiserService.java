package com.cricketLeague.service;

import java.util.List;

import com.cricketLeague.model.Organiser;


public interface IOrganiserService {

	public Organiser getOrganiser(int organiserId);

	public List<Organiser> getAllOrganisers();

	public Organiser insertOrganiser(Organiser organiser);

	public int updateOrganiser(Organiser organiser);

	public int deleteOrgainiser(int organiserId);
	
	public Organiser loginOrganiser(String email, String password);
	
	public int fetchOrganiserId(String name);
	
}
