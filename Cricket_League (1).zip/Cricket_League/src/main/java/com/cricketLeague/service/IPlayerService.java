package com.cricketLeague.service;

import java.util.List;

import com.cricketLeague.model.Player;
import com.cricketLeague.model.Team;

public interface IPlayerService {

	public Player getPlayer(int playerId);

	public List<Player> getAllPlayers();

	public Player insertPlayer(Player player);

	public int updatePlayer(Player player);

	public int deletePlayer(int playerId);

	public String getSkill();

	public Team getTeam();

	
}
