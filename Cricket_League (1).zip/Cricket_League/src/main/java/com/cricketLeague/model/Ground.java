package com.cricketLeague.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Ground_Table")
public class Ground {
	
	@Id
	@GeneratedValue
	private long groundId;
	private String groundName;
	private int capacity;

	@OneToMany(mappedBy = "ground", cascade = CascadeType.ALL)
	private List<Match> matches;

	@OneToOne(cascade = CascadeType.ALL)
	private Address address;

	public Ground() {
	}

	
	//Getters and Setters
	public long getGroundId() {
		return groundId;
	}

	public void setGroundId(long groundId) {
		this.groundId = groundId;
	}

	public String getGroundName() {
		return groundName;
	}

	public void setGroundName(String groundName) {
		this.groundName = groundName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public List<Match> getMatches() {
		return matches;
	}

	public void setMatches(List<Match> matches) {
		this.matches = matches;
	}

	

}
