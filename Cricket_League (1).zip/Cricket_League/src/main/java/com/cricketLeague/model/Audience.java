package com.cricketLeague.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Audience_Table")
public class Audience {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int audienceId;
	private String audienceName;
	private String audienceEmail;
	private double amount;
	private String loginPassword;
	private String emailString;

//	@JsonBackReference
	@ManyToOne
	private Match matches;

	@OneToMany(mappedBy = "audience")
	private List<Ticket> tickets;

	public Audience() {
	}

	public int getAudienceId() {
		return audienceId;
	}

	public void setAudienceId(int audienceId) {
		this.audienceId = audienceId;
	}

	public String getAudienceName() {
		return audienceName;
	}

	public void setAudienceName(String audienceName) {
		this.audienceName = audienceName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Match getMatches() {
		return matches;
	}

	public void setMatches(Match matches) {
		this.matches = matches;
	}

	public List<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(List<Ticket> tickets) {
		this.tickets = tickets;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getEmailString() {
		return emailString;
	}

	public void setEmailString(String emailString) {
		this.emailString = emailString;
	}

	public String getAudienceEmail() {
		return audienceEmail;
	}

	public void setAudienceEmail(String audienceEmail) {
		this.audienceEmail = audienceEmail;
	}
	

}
