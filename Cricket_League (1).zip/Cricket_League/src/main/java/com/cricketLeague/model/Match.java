package com.cricketLeague.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Match_Table")
public class Match {

	@Id
	@GeneratedValue
	private long matchId;

//	@JsonBackReference
	@ManyToOne
	private Team team1;
	
//	@JsonBackReference
	@ManyToOne
	private Team team2;

	@JsonBackReference
	@ManyToOne
	private Tournament tournament;

	
	@OneToOne(cascade = CascadeType.ALL)
	private Schedule schedule;

//	@JsonBackReference
	@ManyToOne
	private Ground ground;

	@OneToMany(mappedBy = "matches")
	private List<Audience> audience =  new ArrayList<>();

	public Match() {
	}

	
	//Getters and Setters
	public long getMatchId() {
		return matchId;
	}

	public void setMatchId(long matchId) {
		this.matchId = matchId;
	}

	public Team getTeam1() {
		return team1;
	}

	public void setTeam1(Team team1) {
		this.team1 = team1;
	}

	public Team getTeam2() {
		return team2;
	}

	public void setTeam2(Team team2) {
		this.team2 = team2;
	}

	public Tournament getTournament() {
		return tournament;
	}

	public void setTournament(Tournament tournament) {
		this.tournament = tournament;
	}

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public Ground getGround() {
		return ground;
	}

	public void setGround(Ground ground) {
		this.ground = ground;
	}

	public List<Audience> getAudience() {
		return audience;
	}

	public void setAudience(List<Audience> audience) {
		this.audience = audience;
	}

}
