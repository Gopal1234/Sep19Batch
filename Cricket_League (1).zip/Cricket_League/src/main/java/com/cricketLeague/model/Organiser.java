package com.cricketLeague.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "Organiser_Table")
public class Organiser {
	
	@Id
	@GeneratedValue
	private int organiserId;
	private String organiserName;
	private String email;
	private long phone;
	private String loginPassword;

//	@JsonManagedReference
	@OneToMany(mappedBy = "organiser")
	private List<Tournament> tournaments =  new ArrayList<>();

	
	//Constructor
	
	//Getters and Setters
	public int getOrganiserId() {
		return organiserId;
	}

	public void setOrganiserId(int organiserId) {
		this.organiserId = organiserId;
	}

	public String getOrganiserName() {
		return organiserName;
	}

	public void setOrganiserName(String organiserName) {
		this.organiserName = organiserName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

//	public double getPayment() {
//		return payment;
//	}
//
//	public void setPayment(double payment) {
//		this.payment = payment;
//	}
//
//	public double getBudget() {
//		return budget;
//	}
//
//	public void setBudget(double budget) {
//		this.budget = budget;
//	}

	public List<Tournament> getTournaments() {
		return tournaments;
	}

	public void setTournaments(List<Tournament> tournaments) {
		this.tournaments = tournaments;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	
	
}
