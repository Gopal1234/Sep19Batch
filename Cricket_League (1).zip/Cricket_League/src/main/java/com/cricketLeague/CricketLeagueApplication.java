package com.cricketLeague;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CricketLeagueApplication {

	public static void main(String[] args) {
		SpringApplication.run(CricketLeagueApplication.class, args);
	}

}
