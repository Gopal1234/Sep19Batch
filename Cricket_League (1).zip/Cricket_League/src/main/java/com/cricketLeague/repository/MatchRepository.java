package com.cricketLeague.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cricketLeague.model.Match;

@Repository
public interface MatchRepository extends JpaRepository<Match, Integer>{
	
//	@Modifying
//	@Transactional
//	@Query(value = "update Match set team1=?2, team2=?3, tournament=?4, schedule=?5, ground=?6 where organiserId=?1")
//	public int updateOrganiser(int id, String name, String email, long phone);

}
