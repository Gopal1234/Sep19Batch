package com.cricketLeague.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cricketLeague.model.Organiser;

@Repository
public interface OrganiserRepository extends JpaRepository<Organiser, Integer>{

	@Modifying
	@Transactional
	@Query(value = "update Organiser set organiserName=?2, email=?3, phone=?4 where organiserId=?1")
	public int updateOrganiser(int id, String name, String email, long phone);
	
	@Query(value = "select organiserId from Organiser where organiserName=?1")
	public int fetchOrganierByName(String name);
}
