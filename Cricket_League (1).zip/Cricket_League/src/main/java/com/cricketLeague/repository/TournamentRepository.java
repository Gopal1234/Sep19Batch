package com.cricketLeague.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.cricketLeague.model.Tournament;


@Repository
public interface TournamentRepository extends JpaRepository<Tournament,Integer> {
	
	@Modifying
	@Transactional
	@Query(value = "update Tournament set tournamentName=?1 where  tournamentId=?2 ")
	public int updateTournament(String tournamentName,int tournamentId);
	
}
