package com.cricketLeague.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cricketLeague.model.Player;
import com.cricketLeague.model.Team;

@Repository
public interface TeamRepository extends JpaRepository<Team, Integer> {
	
	
	//public Team getTeam(int teamId);

	//public List<Team> getAllTeams();

	//public Team insertTeam(Team team);

	@Modifying
	@Transactional
	@Query(value = "update Team set teamName=?2 where teamId=?1")
	public int updateTeam(int id,String name);

	//public int deleteTeam(int teamId);

	/*public List<Player> getAllPlayers();

	public Player getPlayer(int teamId, int playerId);

	public Team getTeam(Player player);*/

}
