package com.cricketLeague.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cricketLeague.model.Audience;
import com.cricketLeague.model.Match;
import com.cricketLeague.model.Ticket;

@Repository
public interface AudienceRepository extends JpaRepository<Audience, Integer> {

	@Modifying
	@Transactional
	@Query(value = "update Audience set audienceName=?2, amount=?3 where audience=?1" )
	public int updateAudience(int id, String name, double amount);
}
