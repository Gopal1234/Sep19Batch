package com.cricketLeague.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricketLeague.model.Audience;
import com.cricketLeague.model.Match;
import com.cricketLeague.repository.AudienceRepository;
import com.cricketLeague.service.IAudienceService;

@Service
public class IAudienceServiceImpl implements IAudienceService {
	
	@Autowired
	private AudienceRepository orgRepo;

	@Override
	public Audience getAudience(int audienceId) {
		return orgRepo.findById(audienceId).get();
		
	}

	@Override
	public Audience insertAudience(Audience audience) {
		return orgRepo.save(audience);
	}

	

}
