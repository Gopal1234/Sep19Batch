package com.cricketLeague.dao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricketLeague.model.Player;
import com.cricketLeague.model.Team;
import com.cricketLeague.repository.PlayerRepository;
import com.cricketLeague.service.IPlayerService;

@Service
public class IPlayerServiceImpl implements IPlayerService {
	@Autowired
	private PlayerRepository repo;

	@Override
	public Player getPlayer(int playerId) {
		Player player=repo.findById(playerId).get();
		
		return player;
	}

	@Override
	public List<Player> getAllPlayers() {
		List<Player> listOfPlayers=repo.findAll();
		
		return listOfPlayers;
	}

	@Override
	public Player insertPlayer(Player player) {
		Player p =repo.save(player);
		
		return p;
	}

	@Override
	public int updatePlayer(Player player) {
		int playerId=player.getPlayerId();
		String playerName=player.getPlayerName();
		double salary=player.getSalary();
		String skill=player.getSkill();
		
		
		
		return repo.updatePlayer(playerId,playerName,salary,skill);
	}

	@Override
	public int deletePlayer(int playerId) {
		repo.deleteById(playerId);
		if(repo.existsById(playerId)) {
			
			return 1;
		}
		return 0;
	}
		
	

	@Override
	public String getSkill() {
		
		return null;
	}

	@Override
	public Team getTeam() {
		
		return null;
	}
	

}
