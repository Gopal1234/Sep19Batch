package com.cricketLeague.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricketLeague.model.Organiser;
import com.cricketLeague.repository.OrganiserRepository;
import com.cricketLeague.service.IOrganiserService;

@Service
public class IOrganiserServiceImpl implements IOrganiserService{
	
	@Autowired
	private OrganiserRepository orgRepo;

	@Override
	public Organiser getOrganiser(int organiserId) {
		return orgRepo.findById(organiserId).get();
	}

	@Override
	public List<Organiser> getAllOrganisers() {
		List<Organiser> listOfOrganisers = orgRepo.findAll();
		return listOfOrganisers;
	}

	@Override
	public Organiser insertOrganiser(Organiser organiser) {
		return orgRepo.save(organiser);
	}

	@Override
	public int updateOrganiser(Organiser org) {
		return orgRepo.updateOrganiser(org.getOrganiserId(), org.getOrganiserName(), org.getEmail(), org.getPhone());
	}

	@Override
	public int deleteOrgainiser(int organiserId) {
		if(orgRepo.existsById(organiserId)) {
			orgRepo.deleteById(organiserId);
			return 1;
		}
		return 0;
	}

	@Override
	public Organiser loginOrganiser(String email, String password) {
		List<Organiser> organisers = orgRepo.findAll();
		for(Organiser org : organisers) {
			if(org.getEmail().equals(email) && org.getLoginPassword().equals(password)) {
				return org;
			}
		}
		return null;
	}

	@Override
	public int fetchOrganiserId(String name) {
		return orgRepo.fetchOrganierByName(name);
	}


}
