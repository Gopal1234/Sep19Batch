package com.cricketLeague.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.core.support.RepositoryFactoryInformation;
import org.springframework.stereotype.Service;

import com.cricketLeague.model.Match;
import com.cricketLeague.repository.MatchRepository;
import com.cricketLeague.service.IMatchService;

@Service
public class IMatchServiceImpl implements IMatchService{
	
	@Autowired
	private MatchRepository repository;

	@Override
	public Match getMatch(int matchId) {
		return repository.findById(matchId).get();
	}

	@Override
	public Match insertMatch(Match match) {
		return repository.save(match);
	}

//	@Override
//	public int updateMatch(Match match) {
//		return  1;
//	}

}
