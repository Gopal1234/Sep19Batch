package com.cricketLeague.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricketLeague.model.Tournament;

import com.cricketLeague.repository.TournamentRepository;
import com.cricketLeague.service.ITournamentService;

@Service
public class TournamentServiceImpl implements ITournamentService {

	@Autowired
	private TournamentRepository repository;
	
	
	@Override
	public Tournament getTournament(int tournamentId) {
		Tournament tournament=repository.findById(tournamentId).get();
		return tournament;
	}

	@Override
	public List<Tournament> getAllTournaments() {
		List<Tournament> listOfTournaments= repository.findAll();

		return listOfTournaments;
	}

	@Override
	public Tournament insertTournament(Tournament tournamentObj) {
		return repository.save(tournamentObj);
	}

	@Override
	public int updateTournament(Tournament tournament) {
		int id= tournament.getTournamentId();
		String name= tournament.getTournamentName();
	int status=	repository.updateTournament(name, id);
		return status;
	}

	@Override
	public int deleteTournament(int tournamentId) {
		repository.deleteById(tournamentId);
	       if(repository.existsById(tournamentId))
	       {
			return 1;
	       }
	       return 0;
		}
	

	

}
