package com.cricketLeague.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricketLeague.model.Team;
import com.cricketLeague.repository.TeamRepository;
import com.cricketLeague.service.ITeamService;

@Service
public class TeamSeviceImpl implements ITeamService {

	@Autowired
	private TeamRepository teamRepository;
	
	@Override
	public Team getTeam(int teamId) {
		// TODO Auto-generated method stub
		return teamRepository.findById(teamId).get();
	}

	@Override
	public List<Team> getAllTeams() {
		// TODO Auto-generated method stub
		List<Team> listOfTeams = teamRepository.findAll();
		return listOfTeams;
	}

	@Override
	public Team insertTeam(Team team) {
		return teamRepository.save(team);
	}

	@Override
	public int updateTeam(Team team) {
		// TODO Auto-generated method stub
		int id = team.getTeamId();
		String name = team.getTeamName();
		
		return teamRepository.updateTeam(id,name);
	}

	@Override
	public int deleteTeam(int teamId) {
		// TODO Auto-generated method stub
		teamRepository.deleteById(teamId);
	    if(teamRepository.existsById(teamId))
	    {
	    	teamRepository.deleteById(teamId);
	    	return 1;
	    }
	       return 0;	
	}

	/*
	@Override
	public List<Player> getAllPlayers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Player getPlayer(int teamId, int playerId) {
		// TODO Auto-generated method stub
		return null;
	}
	*/

}
