package com.cricketLeague.exception;

public class MatchNotFoundException extends RuntimeException {

	public MatchNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public MatchNotFoundException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
}
