package com.cricketLeague.exception;

public class PlayerNotFoundException extends RuntimeException {

	public PlayerNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public PlayerNotFoundException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
}
