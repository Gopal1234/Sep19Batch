package com.cricketLeague.exception;

public class FranchaiseNotFoundException extends RuntimeException {

	public FranchaiseNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public FranchaiseNotFoundException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
}
