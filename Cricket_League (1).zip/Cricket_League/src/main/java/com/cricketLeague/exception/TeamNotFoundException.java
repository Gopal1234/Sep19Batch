package com.cricketLeague.exception;

public class TeamNotFoundException extends RuntimeException {

	public TeamNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public TeamNotFoundException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
}
