package com.cg.creditcardpayment.bean;

public class Account {
	private long accountNumber;
	private String accountName;
	private double balance;
	private String type;
}
