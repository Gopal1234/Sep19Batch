package com.cg.creditcardpayment.bean;

public class User {
	private String userId;
	private String password;
	private String role;
}
