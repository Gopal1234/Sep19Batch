package com.cg.creditcardpayment.bean;

import java.time.LocalDate;

public class CreditCard {
	private long cardId;
	private String bankName;
	private String cardType;
	private String cardName;
	private String cardNumber;
    private LocalDate cardExpiry;
    private int cvv;
    
}
